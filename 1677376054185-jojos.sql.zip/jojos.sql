INSERT INTO dojos (name) 
VALUES ("Chicago"),("L.A"),("Orlando");
SET SQL_SAFE_UPDATES = 0;
DELETE FROM dojos;

SELECT * FROM dojos;

INSERT INTO ninj (first_name, last_name, age,dojo_id)
VAlUES ("Kylie", "Tim", 29,4), ("Bob", "Larry", 25,4), ("Joe", "James", 21,4),
	   ("Andrew", "Mai", 29,5), ("Berry", "Hash", 25,5), ("Boo", "Jameie", 21,5),
       ("Drew", "Cost", 29,6), ("Jas", "Diz", 25,6), ("Reedy", "Breed", 21,6);
       
SELECT * FROM dojos
LEFT JOIN ninj ON dojos.id = ninj._dojo_id
WHERE dojos.id = 4;

SELECT * FROM dojos
LEFT JOIN ninj ON dojos.id = ninj.dojo_id
WHERE dojos.id = (SELECT dojo_id FROM ninj ORDER BY dojo_id DESC LIMIT 1);
       
 SELECT * FROM dojos   
 WHERE dojos.id = (SELECT dojo_id FROM ninj ORDER BY dojo_id DESC LIMIT 1); 